ITRACE WEBSITE FILES

Upload the HTML files in this folder to the ROOT of your GitHub repository:
nicej7630-cpu/itrace-website

Files:
- index.html
- login.html
- dashboard.html
- services.html
- about.html
- contact.html
- faq.html

On GitHub mobile:
1. Open your repository.
2. Tap Add file > Upload files.
3. Extract this ZIP first on your phone, then select the HTML files inside the extracted folder.
4. Upload the files to the repository root (not inside another folder).
5. Commit changes.
6. Open https://nicej7630-cpu.github.io/itrace-website/

IMPORTANT:
This is a demo website interface, not a licensed bank or live banking system. It does not provide real balances, cards, loans, transfers, or payments.
Supabase sign-in uses the public publishable key in login.html. Never put a Supabase secret key in website files.
